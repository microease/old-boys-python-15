# by luffycity.com
staffinfo = 'D:\sylar\s15\staff_info\db\staff_info'
