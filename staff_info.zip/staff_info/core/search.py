# by luffycity.com
'''
查询的逻辑都在本模块中
'''
from conf import settings
def select():
    condition = input('>>>')
    # 收到命令要处理一下
    # 要到文件中去查
    # 要打开文件
    # 文件名怎么取????
    staff_info = settings.staffinfo
    with open(staff_info) as f:
        for line in f:
            print(line.strip())